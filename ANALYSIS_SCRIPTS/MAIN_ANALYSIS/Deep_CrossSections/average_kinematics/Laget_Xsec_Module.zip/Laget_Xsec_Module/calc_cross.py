#
# calculates cross sections
#

import numpy as np
# select of reading binary grid data
use_binary = 1

# import laget module
if use_binary:
    import Laget_Xsec_fp_1 as LX
else:
    import Laget_Xsec_fp as LX
        
import LT.box as B

dtr = np.pi/180.

# initalize arrays: there is a link in the current directory
# assume it is in the current directory
deut_data_dir = './'

# select what kind of calculation and set flags
do_fsi = 0
do_pwia = 1

# select linear interpolation
lin_interp = 1
# do not save the grid as binary file
save_grid = 0

# intitialize the code
if use_binary:
    LX.init_laget('./', do_fsi, lin_interp, save_grid, use_binary)
else:
    LX.init_laget('./', do_fsi, lin_interp)


# read the kinematics file
dk = B.get_file('./kin_av_example.data')

th_cm = B.get_data(dk, 'th_pq_cm')*dtr
omega = B.get_data(dk,  'omega')
q = B.get_data(dk, 'q_lab')
q2 = q**2 - omega**2
cphi = B.get_data(dk, 'cos_phi')
phi = np.arccos(cphi)
Ei = B.get_data(dk, 'Ei')


sigma = []
for i, e0_i in enumerate(Ei):
    # check kinematics
    print "p_rec = ", LX.p_recoil(q2[i], omega[i], th_cm[i])
    # calculate cross sections
    sig = LX.get_sigma_laget(e0_i,q2[i],omega[i],th_cm[i],phi[i])
    sigma.append(sig)



